#! /bin/bash

# ./echo_client 127.0.0.1 9999 ./samples/hello_server

./echo_client 127.0.0.1 9999 ./samples/sample_request_example

# ./echo_client 127.0.0.1 9999 ./samples/sample_request_realistic

# ./echo_client 127.0.0.1 9999 ./samples/request_get